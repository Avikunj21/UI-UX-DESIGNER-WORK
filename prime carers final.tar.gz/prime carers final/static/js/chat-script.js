(function ($, root, undefined) {

	var csrftoken = getCookie('csrftoken'),
		lastChat = getCookie('lastChat'),
		create_msg = '/create_message',
		mrk_msg_read = '/mark_messages_read',
		return_unread = '/return_number_unread';
	
	function setCookie(cname, cvalue, exdays) {
		var d = new Date();
		d.setTime(d.getTime() + (exdays*24*60*60*1000));
		var expires = "expires="+ d.toUTCString();
		document.cookie = cname + "=" + cvalue + "; " + expires;
	}
	function getCookie(name) {
		var cookieValue = null;
		if (document.cookie && document.cookie != '') {
			var cookies = document.cookie.split(';');
			for (var i = 0; i < cookies.length; i++) {
				var cookie = jQuery.trim(cookies[i]);
				// Does this cookie string begin with the name we want?
				if (cookie.substring(0, name.length + 1) == (name + '=')) {
					cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
					break;
				}
			}
		}
		return cookieValue;
	}
	function csrfSafeMethod(method) {
		// these HTTP methods do not require CSRF protection
		return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
	}
	function sameOrigin(url) {
		// test that a given url is a same-origin URL
		// url could be relative or scheme relative or absolute
		var host = document.location.host; // host + port
		var protocol = document.location.protocol;
		var sr_origin = '//' + host;
		var origin = protocol + sr_origin;
		// Allow absolute or scheme relative URLs to same origin
		return (url == origin || url.slice(0, origin.length + 1) == origin + '/') ||
			(url == sr_origin || url.slice(0, sr_origin.length + 1) == sr_origin + '/') ||
			// or any other URL that isn't scheme relative or absolute i.e relative.
			!(/^(\/\/|http:|https:).*/.test(url));
	}
	$.ajaxSetup({
		beforeSend: function(xhr, settings) {
			if (!csrfSafeMethod(settings.type) && sameOrigin(settings.url)) {
				// Send the token to same-origin, relative URLs only.
				// Send the token only if the method warrants CSRF protection
				// Using the CSRFToken value acquired earlier
				xhr.setRequestHeader("X-CSRFToken", csrftoken);
			}
		}
	});
	
	$(document).ready(function() {
		var msd_current =  $('.recepient-msd.current');
		var chat_column =  $(".chat_column"),
			recipient = $(".single_recipient"),
			current_dialog = $('.current_dialog'),
			src_image = current_dialog.find('.single_recipient_img > img').attr('src'),
			current_name = current_dialog.find('.single_recipient_desc .recipient-name').text(),
			current_type = current_dialog.find('.single_recipient_desc .recipient-type').text();
		msd_current.find('.chat_title .single_recipient_desc > img').attr('src', src_image );
		msd_current.find('.chat_title .recipient_name .recipient-name').text(current_name);
		msd_current.find('.chat_title .recipient_name .recipient-type').text(current_type);
		
		/*
		 *		C H A T
		 */
		function chat_height($msgs_list){
			var hScroll = $msgs_list.innerHeight();
			$('.chat-msgs-box').scrollTop( hScroll + 1500 );
		}
		var num = [];
		function last_active_chat() {
			if (lastChat != null ) {
				$('#'+lastChat).addClass('current');
				$('#'+lastChat+'_recipient').addClass('current_dialog');
				chat_height($('#'+lastChat).find('.chat-msgs-list'));
				//head_notification(lastChat);
				setTimeout(function() {
					head_notification(lastChat);
					push_read_message();
				}, 101);
				
			} else {
				$(document).find(".single_recipient").each(function () {
					if ($(this).hasClass('latest') ) {
						var message_id = $(this).attr('id'),
							str = message_id.slice(0, -10),
							current =  $('#' + str),
							targ_id = $(this).data('id');
						current.removeClass('current').addClass('current');
						$(this).addClass('current_dialog');
						chat_height(current.find('.chat-msgs-list'));
						//head_notification(targ_id);
						setTimeout(function() {
							head_notification(targ_id);
							push_read_message();
						}, 101);
						
					}
				});
			}
		}
		function return_number_unread() {
			var nav_chat = $('.nav-item.chat'),
				client_id = nav_chat.data('client'),
				carer_id = nav_chat.data('carer');
			$.ajax({
				url : return_unread, // the endpoint
				type : "POST", // http method
				data : {
					'client_id': parseInt(client_id, 10),
					'carer_id': parseInt(carer_id, 10)
				}, // data sent with the post request
				content_type:'application/json',
				// handle a successful response
				success : function(json) {
					if (json > 0) {
						nav_chat.addClass('have-message').children().find('.dark-green').html('<span class="message_counter">'+json+'</span>');
						$(document).find('.unread').html(json);
					}
					num.push(json);
				},
				// handle a non-successful response
				error : function(xhr,errmsg,err) {
					//console.log(errmsg);
					//console.log(xhr.status + ' ' + err);
				}
			});
		}
		
		function head_notification(targ_id) {
			$('#'+targ_id+'_recipient').find('.message_counter').addClass('hide');
			var _this_no_read = 0,
				message_counter = $('.chat.have-message').find('.message_counter');
			for (var i = 0; i <= num.length; i++) {
				var rval = parseInt(num[i]);
				if (rval > 0) {
					$('#' + targ_id).find('li.chat-message.heautor.no-read').each(function () {
						_this_no_read++;
					});
					var count_unread = rval-_this_no_read;
					if (count_unread != 0) {
						message_counter.html(count_unread);
					} else {
						message_counter.fadeOut();
					}
				} else if (rval == 0) {
					message_counter.fadeOut();
				}
			}
			
			
		}
		
		function push_read_message() {
			var current_dialog = $('.single_recipient.current_dialog'),
				targ_id = current_dialog.data('id');
			
			var messages = [];
			$('#' + targ_id).find('li.chat-message').each(function () {
				if ($(this).hasClass('no-read')) {
					var this_id = $(this).attr('id');
					$(this).removeClass('no-read');
					messages.push(parseInt(this_id, 10));
				}
			});
			
			$.ajax({
				url : mrk_msg_read, // the endpoint
				type : "POST", // http method
				data : {
					'messages[]': messages
				}, // data sent with the post request
				content_type:'application/json',
				// handle a successful response
				success : function(json) {
					return json;
				},
				// handle a non-successful response
				error : function(xhr,errmsg,err) {
					//console.log(xhr.status + ": " + xhr.responseText);
					//console.log(errmsg);
					//console.log(xhr.status + ' ' + err);
				}
			});
		}
		function no_read_notification(id) {
			var count = 0,
				msg_counter = $('[data-id="'+id+'"] .message_counter');
			
			$('#' + id).find('.heautor.no-read').each(function () {
				count++;
			});
			
			if (count == 0) {
				msg_counter.addClass('hide');
			}else if (count > 0) {
				msg_counter.removeClass('hide').html(count);
			}
			return count;
		}
		setTimeout(function() {
			last_active_chat();
			return_number_unread();
			
		}, 90);
		
		// CHAT file set
		$('#chat_file').on('change', function() {
			ch_f_v = $(this).val();
			if( ch_f_v != '' )
				$('label[for="chat_file"]').addClass('isset');
			else
				$('label[for="chat_file"]').removeClass('isset');
		});
		
		recipient.each(function () {
			var targ_id = $(this).data('id');
			if ($(this).parents('#chat').hasClass('client_session')) {
				setTimeout(function() {
					no_read_notification(targ_id);
				}, 100);
			} else if ($(this).parents('#chat').hasClass('carer_session')) {
				setTimeout(function() {
					no_read_notification(targ_id);
				}, 100);
			}
		});
		recipient.click( function(event) {
			event.preventDefault();
			var _this = $(this),
				targ_id = _this.data('id');
			
			
			setTimeout(function() {
				head_notification(targ_id);
			}, 101);
			//cookie
			setCookie('lastChat', targ_id, 100);
			
			$('.recipients_column').addClass('hide');
			
			/* Act on the event */
			if( _this.hasClass('current_dialog') == false){
				// Visio  aside
				var message_id = _this.attr('id'),
					str = message_id.slice(0, -10),
					src = _this.find('.single_recipient_img > img').attr('src'),
					name = _this.find('.single_recipient_desc .recipient-name').text(),
					type = _this.find('.single_recipient_desc .recipient-type').text(),
					_current = $('#' + str),
					_current_list = _current.find('.chat-msgs-list');
				
				$('.single_recipient.current_dialog').removeClass('current_dialog');
				
				_this.addClass('current_dialog');
				$('.chat_column').removeClass('show');
				$('.fa-comment-dots').hide();
				$('.recepient-msd.current').removeClass('current');
				
				_current.removeClass('current').addClass('current');
				
				
				_current.find('.chat_title .single_recipient_desc > img').attr('src', src );
				_current.find('.chat_title .recipient_name .recipient-name').text(name);
				_current.find('.chat_title .recipient_name .recipient-type').text(type);
				
				chat_height(_current_list);
				
				setTimeout(function() {
					push_read_message();
				}, 101);
			}
		});
		
		var bar = $('#chat form .file-progress-bar');
		function create_message(to_mail, from_mail) {
			var mail = $('.recepient-msd.current').data('mail'),
				chat_file = $('#chat_file').val(),
				message = $('.recepient-msd.current #chat-form-textarea'),
				$sender,
				$recipient;
			if (mail == to_mail) {
				$sender = $('[name="sender"]').val(from_mail);
				$recipient = $('[name="recipient"]').val(to_mail);
			} else {
				$sender = $('[name="sender"]').val(to_mail);
				$recipient = $('[name="recipient"]').val(from_mail);
			}
			
			$.ajax({
				url: create_msg, // the endpoint
				type: "POST", // http method
				data: {
					action: 'create_message',
					sender: $sender.val(),
					recipient: $recipient.val(),
					message: message.val(),
					file: chat_file
				}, // data sent with the post request
				beforeSend: function( hz, xhr, o ){
					bar.show();
				},
				// handle a successful response
				success : function(json) {
					bar.hide();
					var msg = '<li id="" class="chat-message iautor seen0" data-to="'+$recipient.val()+'" data-from="'+$sender.val()+'"><div class="message-text">'+ json +'</div><span class="chat-message-info"><span' +
						' class="chat-message-info-time"></span></span></li>';
					
					$('.recepient-msd.current .chat-msgs-list').append(msg);
					
					//return json;
				},
				// handle a non-successful response
				error : function(xhr,errmsg,err) {
					//console.log(xhr.status + ": " + xhr.responseText); // provide a bit more info about the error to the console
				}
				
			});
			return false;
		}
		$(document).on('keypress', '.current #chat-form-textarea', function(e){
			var code = event.keyCode ? event.keyCode : event.which;
			if (code == 13) {
				if (!event.shiftKey) {
					$(this).parent().find('.btn-chat').click();
					return false;
				}
			}
		});
		$(document).on('click', '.current .btn-chat', function(){
			//event.preventDefault();
			var to_mail = $('.recepient-msd.current').find('.chat-message').first().data('to');
			var from_mail = $('.recepient-msd.current').find('.chat-message').first().data('from');
			create_message(to_mail, from_mail);
		});
		//chat back btn
		$('.back_to_list_btn').click(function () {
			$(document).find('.chat_wrapper').find('.recipients_column ').removeClass('hide');
			$(document).find('.chat_wrapper').find('.chat_column').removeClass('show');
		});
		
	});
})(jQuery);