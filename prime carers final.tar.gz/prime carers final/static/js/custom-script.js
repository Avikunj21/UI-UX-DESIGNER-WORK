(function($) {
    $('.search_submit, .filter_submit').on('click', function() {
        gtag_report_conversion();
    });
    $('.nice-checkbox').each(function() {
        $(this).parent().addClass('small_common_checkbox').append('<span class="checkmark"></span>');
    });
    $('.nice-checkbox.register').each(function() {
        $(this).parent().addClass('small_common_checkbox green-checkbox').append('<span class="checkmark"></span>');
    });
    $('input[type="radio"].report-status').each(function() {
        var $input = $(this);
        $input.parent().addClass('common_radio');
    });
    var $task = $('.task-line');
    $task.each(function() {
        var $label = $(this).find('.report-radio > .common_radio');
        var $task_line = $(this);
        $label.each(function() {
            $task_line.find('.status-label').append('<span class="label-col">' + $(this).text() + '</span>');
        });
    });
    $task.first().each(function() {
        var $input_label = $(this).find('.report-label');
        var $radio_label = $(this).find('.label-col');
        $input_label.css({
            'display': 'block'
        });
        $radio_label.css({
            'display': 'block'
        });
    });
    $('#toggle-filter').on('click', function(e) {
        e.preventDefault();
        console.log('click');
        $('#filters').fadeIn();
    });
    $('#filters > .close').on('click', function(e) {
        $('#filters').fadeOut();
    });
    var $footer = $('#footer');
    $(document).ready(function() {
        $('.form-rating input').change(function() {
            console.log('click');
            $('.form-rating label').removeClass('selected');
            var $radio = $(this),
                $hidden_field = $('#id_rating');
            $radio.next().addClass('selected');
            var $rating = $radio.val().toString(),
                $hidden_rating = $hidden_field.val($rating);
        });
        $('.left_control_tab_brn').click(function() {
            var index = $(this).closest('.tab-pane-about').index() - 1;
            var tab = $(this).closest('.tab-pane-about');
            if (tab.is(':first-child')) {
                return;
            } else {
                $(this).closest('.pill-box-tabs').find('.tab-pane-about').removeClass('active show').eq(index).addClass('active show');
                $(this).closest('.pill-tabs').children('.pill-box.tabs').find('li>a').removeClass('active show').eq(index).addClass('active show');
            }
        });
        $('.right_control_tab_brn').click(function() {
            var index = $(this).closest('.tab-pane-about').index() + 1;
            var tab = $(this).closest('.tab-pane-about');
            if (tab.is(':last-child')) {
                return;
            } else {
                $(this).closest('.pill-box-tabs').find('.tab-pane-about').removeClass('active show').eq(index).addClass('active show');
                $(this).closest('.pill-tabs').children('.pill-box.tabs').find('li>a').removeClass('active show').eq(index).addClass('active show');
            }
        });
        $('.round').on('click', function() {
            $(this).closest('li:not(.active)').addClass('active').siblings().removeClass('active');
            $(this).closest('div.round-tabs-container').find('div.tab-pane').removeClass('active').eq($(this.closest('li')).index()).addClass('active');
            $(this).closest('div.round-tabs-container').find('.ft_dot').removeClass('ft_dot_active').eq($(this.closest('li')).index()).addClass('ft_dot_active');
        });
    });
}(jQuery));
